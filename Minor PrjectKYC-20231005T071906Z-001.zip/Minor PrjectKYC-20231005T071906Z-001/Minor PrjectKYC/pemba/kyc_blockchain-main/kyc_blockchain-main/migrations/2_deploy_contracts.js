var Kyc = artifacts.require("./Kyc.sol");

module.exports = function(deployer) {
  deployer.deploy(Kyc);
};
