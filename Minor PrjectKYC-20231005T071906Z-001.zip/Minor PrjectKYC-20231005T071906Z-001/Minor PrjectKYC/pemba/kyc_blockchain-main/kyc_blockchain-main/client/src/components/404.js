import React from 'react'
import { Container } from 'react-bootstrap'

export const NotFound = () =>{
    return(
        <>
            <Container style={{textAlign: "center",paddingTop:"30px"}}>
                <h2>404!! Page Not Found</h2>
            </Container>
        </>
    )
}