module.exports = {
    jwtSecret: 'afd8s8fdf8adf8adf8afa8dfgsfgsv8z5z5z032vvc',
    jwtExpire: '24h'
};