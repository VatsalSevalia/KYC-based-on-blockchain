import React from 'react'

const AdminDashboard = () => {
    return (
        <div>
            Inside Admin Dashboard
        </div>
    )
}

export default AdminDashboard;
