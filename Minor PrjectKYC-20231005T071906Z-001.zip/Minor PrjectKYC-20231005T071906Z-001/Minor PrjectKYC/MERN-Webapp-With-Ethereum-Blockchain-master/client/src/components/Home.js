import React from 'react';

function Home() {
    return (
        <div>
            From Home.
        </div>
    )
        // <div className="home">
        //     <div className="home__header">
        //         <Header />
        //     </div>

        //     <div className="home__body">
        //         <div className="home__leftSide">
        //             <Leftbody />
        //         </div>

        //         <div className="home__middleSide">
        //             <Middlebody />
        //         </div>

        //         <div className="home__rightSide">
        //             <Rightbody />
        //         </div>
        //     </div>
        // </div>
    
}

export default Home
