import React from "react";

const NotFound = () => {
 return(
    <h1>Sorry cant resolve What you are looking for</h1>
 )
}


export default NotFound;