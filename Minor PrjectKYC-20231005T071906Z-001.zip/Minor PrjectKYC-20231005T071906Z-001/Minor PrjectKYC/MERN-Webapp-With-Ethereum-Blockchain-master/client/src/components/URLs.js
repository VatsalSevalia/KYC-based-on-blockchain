let URLs = {};


  URLs = {
    baseURL: "http://localhost:5000/api",
    socketURL: "http://localhost:5001",
  };

export default URLs;