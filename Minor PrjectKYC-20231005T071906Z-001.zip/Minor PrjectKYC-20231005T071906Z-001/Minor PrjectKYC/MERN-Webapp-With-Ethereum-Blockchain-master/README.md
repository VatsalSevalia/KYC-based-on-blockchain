# ReactBlockchain__dapp
Bank Webapp with KYC running in the Blockchain



To  Start the App you need to do some stuffs going on 


-clone the repositories 
-npm install


-download the ganache 

-go on with mongo db atlas create the database from your accout 
- In Backend - database - db.js (add your username and password of the project )


- Go on with npm  run dev inside backend forlder 
- it starts your WebApp

